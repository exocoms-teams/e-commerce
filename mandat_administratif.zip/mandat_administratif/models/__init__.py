# -*- coding: utf-8 -*-
from . import payment_provider
from . import payment_transaction
from . import res_company
from . import res_config_settings
from . import res_partner
from . import sale_order
from . import account_move
from . import account_edi_xml
